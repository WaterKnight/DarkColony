Advanced Sentry Tower
By The_Silent

Description:
Well an advanced tower, could be used for an tesla tower, prism tower, laser tower, plasma tower and many more. My submission Mini-Modeling Contest #4.

-Enjoy ^^

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, October 17
Model was last updated 2010, October 17


Visit http://www.hiveworkshop.com for more downloads