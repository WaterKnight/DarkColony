Blind Beast
By tee.dubs

Description:
A little more threatening than the last, this creature is rather beastly. It is completely blind and senseless, it just kills stuff without knowing it.

[HIDDEN="Background Story: READ"][QUOTE=Crazy Cow;1486155]
Created by Yog'sarron as the next generation of warriors for his army, the blind beasts serve as elite support for his Faceless armies. Originally common domesticated dogs, Yog'Sarron's dark magic has turned them into powerhouses of destruction going far beyond their previous lives and bonds. There have been scattered reports of their powers, from breathing fire to reincarnating soon after death, but they are so contradictory that none can be trusted.
[/QUOTE]

Thanks to Crazy Cow for a nifty little story, you can find the rest of it [URL="http://www.hiveworkshop.com/forums/screenwriting-storyboarding-concept-creation-291/blind-beast-story-159715/"]here[/URL].[/HIDDEN]
[HIDDEN="Model Specs"]
561 Vertexes, 754 Faces. Probably best used as a rare creep or a cave boss or something. Also the walk animation is pretty fast, you might want to slow it down a little in the WE. It uses the Faceless One texture; there's plenty custom skins in the resource section, you might just be able to get some gnarly tones out of it if you pick them right.

Stand - 1: Stands normally
Stand - 2: Looks to the side ominously
Stand - 3: Stretches his muscles
Walk: Walks
Attack - 1: Attacks using both claws
Attack - 2: Swipes both claws independently
Attack Slam: Whacks his face tentacles at the foe
Spell Channel: Cannibalism spell
Portrait: A portrait of the creature
Portrait Talk: Communication between beast and user
Death: Dies
Decay Flesh: The body sinks into the ground, the bones remain
Decay Bone: The bones dissolve and disappear

I'd suggest the dragon hatchling soundset, it seems rather appropriate for some reason.[/HIDDEN]

[HIDDEN="Edits"]EDIT1: Added death sound and bloodspats. I think.

EDIT2: Ok I'm still not quite sure about the death sound and bloodspats, but if they don't work this time i'll just remove them completely. Also added some particles.

EDIT3: I forgot to change the deathsound. I think it works now, i tested it in the word editor but that's as far as i can go. Hope it's all good now, otherwise i'll weep. Also cleaned up the description :) [/HIDDEN]


REMEMBER, CREDITS GUYS. ENJOI.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, February 24
Model was last updated 2010, September 6


Visit http://www.hiveworkshop.com for more downloads