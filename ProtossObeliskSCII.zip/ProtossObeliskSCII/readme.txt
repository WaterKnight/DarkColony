Protoss Obelisk (SCII)
By Revilo and M0rbid

Description:
[IMG]http://www.hiveworkshop.com/forums/members/184486-albums3456-picture57703.png[/IMG]

EDIT: fixed the filesize bug.

Textures:
ProtossObeliskTexture256.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2012, April 29
Model was last updated 2012, May 1


Visit http://www.hiveworkshop.com for more downloads