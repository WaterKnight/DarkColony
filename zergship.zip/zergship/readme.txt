zerg ship
By Pyritie and The_Silent

Description:
me and The_Silent's entry for modeling contest #20

model by him, unwrap, textures, and animations by me

give credits yadda yadda

[URL=&quot;http://pyritie.deviantart.com/art/Flying-leechy-thingy-Stand-245141757&quot;][img]http://fc09.deviantart.net/fs70/i/2011/209/d/2/flying_leechy_thingy___stand_by_pyritie-d41y8l9.gif[/img][/URL] [URL=&quot;http://pyritie.deviantart.com/art/Flying-leechy-thingy-Walk-245143133&quot;][img]http://fc00.deviantart.net/fs70/i/2011/209/b/3/flying_leechy_thingy___walk_by_pyritie-d41y9nh.gif[/img][/URL] [URL=&quot;http://pyritie.deviantart.com/art/Flying-leechy-thingy-Load-245144103&quot;][img]http://fc04.deviantart.net/fs71/i/2011/209/f/4/flying_leechy_thingy___load_by_pyritie-d41yaef.gif[/img][/URL] [URL=&quot;http://pyritie.deviantart.com/art/Flying-leechy-thingy-Death-245145386&quot;][img]http://fc07.deviantart.net/fs71/i/2011/209/f/f/flying_leechy_thingy___death_by_pyritie-d41ybe2.gif[/img][/URL]

Textures:
zerg transport ship.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2011, July 31
Model was last updated 2011, August 1


Visit http://www.hiveworkshop.com for more downloads