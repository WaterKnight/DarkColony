Goblin Slammer
By jk2pach

Description:
A little model made for a hero contest .
It can be used as a hero or unit.

Attack animations means to use it as a melee Hero.
Attack-1, Attack-2 and Attack-Slam: the rocket pod is thrown on the target
Spell: To fire missiles; works with spells like Rockets
Spell Throw: to use the gun. Works better with spells like shockwave or Healing spray
Death: the goblin is ejected.
Walk: I do not know how to create animated textures, sorry.
Defend tag: simply swith the flares on.

Of course I would appreciate the fact you give credits.
Permission to edit the model is granted ofc, but it is same: my name somewhere in the credits could be nice from you.

Update Log
[HIDDEN]
16 Oct 2009
59th version
-Spell and Spell Throw animation reduced in time
-Particle Count of dust in Walk animation reduced

08th Oct 2009
58th version
-Fixed the walk defend animation (No more particles from other animations)
-Added a tooltip on this message about animations.
-Reduced the smoke of the walk animations.

55th version
-Major changes to respect the moderation report
-New design for cockpit; now it does not look like a Crystal shard.
-One rocket pod removed, replaced with a hudge gun
-Attack 1, 2 and Slam animation changed
-Death animation: the eject of the Goblin does not use a hidden geoset anymore; particles modified and shockwave added.
-Particles reduced
-Spell animation: particles look like more fire in order to imitate a rocket fire
-Spell Thow animation: smoke added
-Defend animations: light changed
-Spell and Spell Throw animations: light added
-Goblin design changed. It uses now the classic Tinker design.
-Hero glow removed
-Size of the model reduced
-Chains modified; I have added bones on it, allowing a more realistic move and more than all no texture zoom.

20th Sept 2009
23rd version
-Animations added: Spell Throw (using a machinegun), Walk Defend, Stand Defend (using a flare and a light source)
-Changed the color of the smoke for the Decay animation
-Changed the Death animation: now the Goblin ejects the cockpit ;)

19th Sept 2009
8th version.
-Helmet changed, I use a lighter one.
-Dust particle fixed in walk animation.

11:12, 18th Sep 2009
Last changes: in order to fixt what was pointed about the weakness of this model:
-Walk animation: smoke added to the tracks
-Cockpit: other texture used, looks more realist. 
-Cockpit: a bit modified the structure. Centered.
-Death animation: minor changes in the particles.
-Decay animation: added some smoke.

Edit:
Cockpit changed.
[/HIDDEN]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, September 17
Model was last updated 2009, October 16


Visit http://www.hiveworkshop.com for more downloads