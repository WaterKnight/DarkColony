Heliport
By SataX

Description:
A model which I made for my map Lego Wars.
No custom textures, small size. Enjoy, and don't forget to credit.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, May 26
Model was last updated 2009, May 26


Visit http://www.hiveworkshop.com for more downloads