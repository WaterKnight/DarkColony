JetpackDwarf

Description:
A new foundation of crazy gnome tinkers - flying dwarf!

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Karlson.blp
Textures\Dust3x.blp
Textures\Flame4.blp
Textures\gyrocopter.blp

Downloaded from http://www.hiveworkshop.com