Scantid
By HappyCockroach

Description:
A creepy scorpion from SC. But you can download it, it is unoffensive. :ugly:

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, May 16
Model was last updated 2010, May 17


Visit http://www.hiveworkshop.com for more downloads