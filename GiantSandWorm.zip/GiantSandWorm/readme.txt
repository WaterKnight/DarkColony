GiantSandWorm
By GiantSandWorm

Description:
GiantSandWorm V1.2
By: Sephiroth_VII
     aka Daniel Manion
      aka Newbwc3

Important: This model takes alot of custom WE settings to make it work the way intended, I also made abilitys for it (sandbreath,Devour,eatTree,Hardenedskin,Earthquake,Slam,Hurlboulder) edited the breathofFire missile to look like sand) To see it in action with all event objects, abilities, sounds, ect.. take a look at the test map I made here:

&gt;TESTMAP: http://www.thehelper.net/forums/showthread.php?t=83140

refer to the testmap to see how to import it into your map like its done in the test map.

*Do NOT modify or redistribute this model in any way.*
*Give Credit to &quot;Sephiroth_VII&quot;*

comments &amp; criticisim plz.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, February 18
Model was last updated 2008, February 23


Visit http://www.hiveworkshop.com for more downloads