Installation Foundry
By shamanyouranus

Description:
A Foundry model I made for my work in progress, top-secret, definitely-not-a-space-orc-map map. Enjoy it...enjoy it NAOW!
Comments and criticisms are ENCOURAGED, because this is definitely not a final product.


Do not edit or distribute without my permission.
You must give credit to [i]shamanyouranus[/i] if you use this in your map or campaign.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, March 8
Model was last updated 2010, March 8


Visit http://www.hiveworkshop.com for more downloads