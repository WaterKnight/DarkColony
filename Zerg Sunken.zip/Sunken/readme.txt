Sunken
By killst4r

Description:


Textures:
Sunken.blp
ZergBuilding.blp
Blood2.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2004, June 5
Model was last updated 2004, June 5


Visit http://www.hiveworkshop.com for more downloads