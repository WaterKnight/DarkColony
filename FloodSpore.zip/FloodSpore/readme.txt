Flood Spore
By Fingolfin

Description:
I noticed a lot of people were requesting halo models, and i really couldn't see them making a halo map without this little fella. :)
I did this for a halo project of my own that i was working on for a while, and hopefully it will be continued, but if not, i will release all my other models for it later.
But untill then, DON'T bother me with request, or ask me if you can have any of them.

Feel free to make any skins or edits on this model, but make sure to give credit.

EDIT: For those of you who don't know what this is: The flood is a parasitic creature featured in the Halo games, that infests sentient bodies and use them as hosts. 
Infected bodies suffer from great mutation and disformation.

UPDATE: Lowered particle count to about half.
[SIZE=&quot;4&quot;][B]LARGE UPDATE:[/B]
*Added Spell Death animation
*Increased *POP*-ness in regular and spell death animation
*Added a third walk animation in wich the unit jumps about twice as high as in the second walk anim
*Flesh pieces now fade away before dissapearing[/SIZE]

Small update: Fixed name of Spell Death anim.

Another small update:
Here you go misha, alternate death name changed to "death spell".

EDIT: I noticed this model did not have a proper death sound, like the earlier version had. That is fixed now. Also rounded extents and coordinates of some stuff, might reduce size, i dunno.

Textures:
Flood_Spore.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, December 3
Model was last updated 2011, September 4


Visit http://www.hiveworkshop.com for more downloads