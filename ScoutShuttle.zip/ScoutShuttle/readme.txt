Scout Shuttle
By jk2pach

Description:
A ship for space maps.
Please give credits if used.
Used in my map Stars ( [url]http://www.hiveworkshop.com/forums/maps-564/stars-1-14-beta2-124565/[/url] )

Last update: normals fixed as requested

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, June 21
Model was last updated 2010, November 2


Visit http://www.hiveworkshop.com for more downloads