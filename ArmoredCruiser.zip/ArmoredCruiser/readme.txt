Armored Cruiser
By jk2pach

Description:
A heavy ship used as a tank against enemy fleets.

Please give credits if used.

Used in my map Stars ( [url]http://www.hiveworkshop.com/forums/maps-564/stars-1-14-beta2-124565/[/url] )


Last Update: Armor added, Particle Emitters changed (to make them ingame visibles)

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, June 21
Model was last updated 2009, December 13


Visit http://www.hiveworkshop.com for more downloads